﻿namespace ChocolateStore
{
    class Arguments
    {
        public string Directory { get; set; }
        public string Url { get; set; }
    }
}
